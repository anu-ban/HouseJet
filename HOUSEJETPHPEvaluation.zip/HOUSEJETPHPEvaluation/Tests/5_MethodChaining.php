<?php
// Finish the Calculator class in a way that allows method chaining
interface CalcInterface {
    public function setValue(int $v);
    public function getValue() : int;
    public function add(int $v);
    public function subtract(int $v);
}

class Calculator implements CalcInterface {

}

$calc = new Calculator();
assert($calc->setValue(10)->add(2)->subtract(3)->getValue() === 9);

$calc = new Calculator();
assert($calc->add(10)->add(10)->add(10)->subtract(5)->getValue() === 25);
