<?php

function add(int $a, int $b) : int {
    // Your code here
}

function multiply(int $a, int $b) : int {
    // Your code here
}

function divide(int $numerator, int $denominator) {
    // your code here
}



// basic assertions
assert(add(1,2) === 3);
assert(add(11, -5) === 6);

assert(multiply(1,4) === 4);
assert(multiply(8,3) === 24);

assert(divide(8,2) === 4);
assert(divide(1,2) === 0.5);
