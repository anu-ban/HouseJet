<?php

function removeFirstItem(array $a) : array {
    // your code here
}

function removeLastItem(array $a) : array {
    // your code here
}

function reverseArray(array $a) : array {
    // your code here
}

// Given an array like [['name' => 'Apple', 'type' => 'fruit'], ['name' => 'Dog', 'type' => 'animal']]
// return only those with the specified type
function filterByType(array $a, string $type) : array {

}

// systematically return all pairs of odd numbers up to $max number
// expected return value [[1,1],[1,3],[3,1],[3,3]...]
function oddNumberPairs(int $max){

}

assert(removeFirstItem(['Atlanta', 'Metro', 'Area']) === ['Metro', 'Area']);
assert(removeLastItem(['Springfield', 'Ozark', 'Nixa', 'Branson']) === ['Springfield', 'Ozark', 'Nixa']);
assert(reverseArray(['Walnut', 'Jefferson', 'Elm']) === ['Elm', 'Jefferson', 'Walnut']);

$typesArray = [
    ['name' => 'Apple', 'type' => 'fruit'],
    ['name' => 'Dog', 'type' => 'animal'],
    ['name' => 'Corvette', 'type' => 'car'],
    ['name' => 'Pear', 'type' => 'fruit'],
    ['name' => 'Sloth', 'type' => 'animal']
];

assert(filterByType($typesArray, 'animal') === [['name' => 'Dog', 'type' => 'animal'], ['name' => 'Sloth', 'type' => 'animal']]);
assert(filterByType($typesArray, 'people') === []);

assert(oddNumberPairs(6) === [[1,1],[1,3],[1,5],[3,1],[3,3],[3,5],[5,1],[5,3],[5,5]]);