<?php

// This is designed to emulate a binary permission system

class Permissions {
    const int READ = 1;
    const int WRITE = 2;
    const int DELETE = 4;
    const int PUSH = 8;
    const int PULL = 16;
    const int FLING = 32;
    const int FLY = 64;

    private int $userPermission = 0;

    public function addPermission(int $permissionValue) : void {
        // your code here
    }

    public function removePermission(int $permissionValue) : void {
        // your code here
    }

    public function hasPermission(int $permissionValue) : bool{
        // your code here
    }
}

$permissions = new Permissions();
$permissions->addPermission(Permissions::READ);
assert($permissions->hasPermission(Permissions::READ));
assert(!$permissions->hasPermission(Permissions::WRITE));

$permissions->addPermission(Permissions::FLING);
$permissions->addPermission(Permissions::READ);
assert($permissions->hasPermission(Permissions::FLING));
assert($permissions->hasPermission(Permissions::READ));

$permissions->removePermission(Permissions::READ);
$permissions->removePermission(Permissions::DELETE);
assert(!$permissions->hasPermission(Permissions::READ));
assert(!$permissions->hasPermission(Permissions::DELETE));
assert($permissions->hasPermission(Permissions::FLING));
