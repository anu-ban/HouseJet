<?php

function reverseString(string $text) : string{
    // your code here
}

function replaceNthWord(string $phrase, int $n, string $replacementWord) : string {
    // your code here
}

function removeNumbers(string $text) : string {
    // your code here
}

function isValidEmailFormat(string $email) : bool {
    // your code here
}

assert(reverseString('abcdefg') === 'gfedcba');
assert(replaceNthWord('The Quick Brown Fox', 3, 'Red') === 'The Quick Red Fox');
assert(removeNumbers('I have 1 apple and 2 grapes') === 'I have  apple and  grapes');
assert(isValidEmailFormat('brandon@housejet.com'));
assert(!isValidEmailFormat('brandon@gmail'));
